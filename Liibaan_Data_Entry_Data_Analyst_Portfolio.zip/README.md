# Liibaan — Data Entry & Junior Data Analyst Portfolio

## Professional Summary
Junior Data Analyst and Data Entry Specialist focused on accurate data management, cleaning, validation, reporting, Excel, Google Sheets, and SQL. This portfolio demonstrates practical skills using synthetic datasets created for practice and demonstration.

## Core Skills
- Data Entry & Data Management
- Microsoft Excel & Google Sheets
- Data Cleaning & Validation
- Data Quality Control
- SQL querying and relational data analysis
- Reporting and business insights
- Attention to detail and documentation

## Projects

### 1. Excel Sales Analysis
**Tools:** Microsoft Excel  
**Skills:** formulas, aggregation, summaries, data organization, charting

File: `Excel_Sales_Analysis.xlsx`

### 2. Data Entry & Cleaning Dataset
**Tools:** CSV / Excel  
**Skills:** structured data entry, validation, formatting, quality control

Files: `customer_data.csv`, `sales_data.csv`

### 3. SQL Data Analysis
**Tools:** SQLite / SQL  
**Skills:** SELECT, WHERE, GROUP BY, ORDER BY, JOIN, aggregation

Files: `analysis_queries.sql`, `portfolio_database.sqlite`

## Data Privacy
All records in this portfolio are **synthetic practice data**. No real customer or confidential company information is included.

## Contact
**Liibaan Cabdullahi Cabdirahman**  
Data Entry | Junior Data Analyst
