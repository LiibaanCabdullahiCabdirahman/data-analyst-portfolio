# Excel Sales Analysis

## Objective
Analyze sales transactions and create a concise management-ready summary.

## Skills Demonstrated
- Excel table organization
- Revenue calculation
- Product-level aggregation
- Customer-level summary
- Data visualization

## Key Metric
Revenue is calculated as:

`Unit Price × Quantity`

## File
`Excel_Sales_Analysis.xlsx`
