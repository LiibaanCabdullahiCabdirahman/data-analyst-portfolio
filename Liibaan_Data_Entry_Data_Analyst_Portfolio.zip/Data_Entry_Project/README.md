# Data Entry & Data Quality Project

## Objective
Demonstrate accurate structured data entry, organization, validation, and quality control.

## Work Demonstrated
- Consistent field formatting
- Unique customer IDs
- Standardized city and date values
- Structured CSV output
- Basic data-quality review

## Dataset
`customer_data.csv`

> Synthetic practice data created for portfolio demonstration.
